import math
import numpy as np
###预设
T=0.0724*(39)**0.8*1.4##   m
# T=1.6
print('T=',T)
Tg = 0.45
M=5721836.734693877##质量 kg
Ss = 1.0
S1 = 0.85
Fv = 1.3
Fa = 2.4
Sms = Ss*Fa
Sm1 = S1*Fv
T0 = 0.2*(Sm1/Sms)
Ts = (Sm1/Sms)
if T<=T0:
    Sa_MCE = Sms*(0.4+0.6*(T/T0))
    Sa_DBE = (2/3)*Sa_MCE
if T0<T<=Ts:
    Sa_MCE = Sms
    Sa_DBE = (2/3)*Sa_MCE
if Ts<T<=4.0:
    Sa_MCE = Sm1/T
    Sa_DBE = (2/3)*Sa_MCE
if T>4:
    Sa_MCE = Sm1*4/(T**2)
# print('Sa_DBE=',Sa_DBE,'Sa_MCE=',Sa_MCE)
theta1_ = 0.3##预设目标位移角  %
theta2_ = 1.5
theta3_ = 1.8
theta4_ = 2.25
ξ   = 0.05##阻尼比
a1_ = 0.05
a2_ = 0.6
a3_ = 0.1
ξ1_ = theta2_/theta1_
ξ2_ = theta3_/theta1_
miu = theta4_/theta1_
gama_DBE =0.3456373418360746
gama_MCE =0.2805998623371124 #能量系数 
g =9.8 #重力加速度 N/kg  m/s^2
##子结构
l=4600##mm
l3=1250## mm

h1 = 1400+1333+1400##第一层子结构层高  
h2 = 4200##第二层子结构层高
h3 = 4200##第三层子结构层高
h4 = 4200##第四层子结构层高
h5 = 4200##第五层子结构层高
h6 = 4200##第六层子结构层高
h7 = 4200##第七层子结构层高
h8 = 4200##第八层子结构层高
h9 = 4200-1400##第九层子结构层高  
H_t = 39000 ###结构总高度
N_damp = 20 ##一层阻尼器的数量
##能量  预期各阶段基底剪力
eta_MCE = (2*(1-a1_)*(miu-1)+(a2_-a1_)*(ξ2_-ξ1_)*(2*miu-ξ1_-ξ2_)+(a3_-a1_)*(miu-ξ2_)**2)/(2*miu-1+a1_*(ξ1_-1)*(2*miu-ξ1_-1)+a2_*(ξ2_-ξ1_)*(2*miu-ξ1_-ξ2_)+a3_*(miu-ξ2_)**2)  ##塑性能量比
Ry_MCE = math.sqrt((2*miu-1+a1_*(ξ1_-1)*(2*miu-ξ1_-1)+a2_*(ξ2_-ξ1_)*(2*miu-ξ1_-ξ2_)+a3_*(miu-ξ2_)**2)/gama_MCE) ##强度比  Fe/Fy
Ry_DBE = math.sqrt((2*ξ1_-1+a1_*(ξ1_-1)**2)/gama_DBE)
###每层地震重量 到基底高度  分配系数
W1 = 6348.0*10**3 #kN
W2 = 6348.0*10**3 #kN
W3 = 6348.0*10**3 #kN
W4 = 6348.0*10**3 #kN
W5 = 6348.0*10**3 #kN
W6 = 6348.0*10**3 #kN
W7 = 6348.0*10**3 #kN
W8 = 6348.0*10**3 #kN
W9 = 5290.0*10**3 #kN
H1 = 5400  #mm
H2 = 9600  #mm
H3 = 13800 #mm
H4 = 18000 #mm
H5 = 22200 #mm
H6 = 26400 #mm
H7 = 30600 #mm
H8 = 34800 #mm
H9 = 39000 #mm
beta1 = ((W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta2 = ((W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta3 = ((W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta4 = ((W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta5 = ((W5*H5+W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta6 = ((W6*H6+W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta7 = ((W7*H7+W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta8 = ((W8*H8+W9*H9)/(W9*H9))**(0.75*T**(-0.2))
beta9 = ((W9*H9)/(W9*H9))**(0.75*T**(-0.2))
Cv1 = (beta1-beta2)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2))) ##第一层分配系数
Cv2 = (beta2-beta3)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第二层分配系数
Cv3 = (beta3-beta4)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第三层分配系数
Cv4 = (beta4-beta5)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第四层分配系数
Cv5 = (beta5-beta6)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第五层分配系数
Cv6 = (beta6-beta7)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第六层分配系数
Cv7 = (beta7-beta8)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第六层分配系数
Cv8 = (beta8-beta9)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第六层分配系数
Cv9 = (beta9-0)*(((W9*H9)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6+W7*H7+W8*H8+W9*H9))**(0.75*T**(-0.2)))##第六层分配系数
Ee= 1000*M*T**2*Sa_MCE**2*g**2/(8*(math.pi)**2)##总弹性能  由伪加速度求  N·mm
Ep = Ee*gama_MCE*eta_MCE ##总塑性需求能  N·mm
b_MCE = (8*math.pi**2*((theta4_/100-theta1_/100)+((a1_*(theta2_/100-theta1_/100)*(2*theta4_/100-theta1_/100-theta2_/100)+a2_*(theta3_/100-theta2_/100)*(2*theta4_/100-theta3_/100-theta2_/100)+a3_*(theta4_/100-theta3_/100)**2))/(2*theta1_/100))*(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6+Cv7*H7+Cv8*H8+Cv9*H9))/(T**2)
Vy1_MCE=M/1000*(((-b_MCE+math.sqrt(b_MCE**2+4*gama_MCE*(Sa_MCE*g*1000)**2)))/2)
# print('V1_MCE_能量=',Vy1_MCE)
b_DBE = (8*math.pi**2*((theta2_-theta1_)/100+a1_*(theta2_-theta1_)**2/(2*theta1_*100))*(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6+Cv7*H7+Cv8*H8+Cv9*H9))/(T**2)
Vy1_DBE=M/1000*(((-b_DBE+math.sqrt(b_DBE**2+4*gama_DBE*(Sa_DBE*g*1000)**2)))/2)
# print('V1_DBE_能量=',Vy1_DBE)
V1_max = max(Vy1_MCE,Vy1_DBE)
print('V1max=',V1_max)
Vy1 = V1_max
K = Vy1*100/(theta1_*H_t)
Vy2 = Vy1+((theta2_-theta1_)*H_t/100)*a1_*K##预期结构的第二阶段的总屈服力
Vy3 = Vy2+((theta3_-theta2_)*H_t/100)*a2_*K##预期结构的第三阶段的总屈服力
Vy4 = Vy3+((theta4_-theta3_)*H_t/100)*a3_*K##预期结构的第四阶段的总屈服力
##第一阶段
###各层的侧向力分布
Fy1_1 = Cv1*Vy1  ##第一层侧向力     N
Fy1_2 = Cv2*Vy1  ##第二层侧向力     N
Fy1_3 = Cv3*Vy1  ##第三层侧向力     N
Fy1_4 = Cv4*Vy1  ##第四层侧向力     N
Fy1_5 = Cv5*Vy1  ##第五层侧向力     N
Fy1_6 = Cv6*Vy1  ##第六层侧向力     N
Fy1_7 = Cv7*Vy1  ##第七层侧向力     N
Fy1_8 = Cv8*Vy1  ##第八层侧向力     N
Fy1_9 = Cv9*Vy1  ##第九层侧向力     N
# print(Fy1_1,Fy1_2,Fy1_3)
##各层的设计层间剪力  用上柱剪力  用于子结构设计
Vy1_1 = Fy1_1+Fy1_2+Fy1_3+Fy1_4+Fy1_5+Fy1_6+Fy1_7+Fy1_8+Fy1_9  ##第一层设计层间剪力 N
Vy1_2 = Fy1_2+Fy1_3+Fy1_4+Fy1_5+Fy1_6+Fy1_7+Fy1_8+Fy1_9  ##第二层设计层间剪力 N
Vy1_3 = Fy1_3+Fy1_4+Fy1_5+Fy1_6+Fy1_7+Fy1_8+Fy1_9  ##第三层设计层间剪力 N
Vy1_4 = Fy1_4+Fy1_5+Fy1_6+Fy1_7+Fy1_8+Fy1_9
Vy1_5 = Fy1_5+Fy1_6+Fy1_7+Fy1_8+Fy1_9
Vy1_6 = Fy1_6+Fy1_7+Fy1_8+Fy1_9
Vy1_7 = Fy1_7+Fy1_8+Fy1_9
Vy1_8 = Fy1_8+Fy1_9
Vy1_9 = Fy1_9
##各层的阻尼器弯矩值  静力平衡
My1_1 = Vy1_1*h1*l3/(l*N_damp) ##N·mm
My1_2 = Vy1_2*h2*l3/(l*N_damp)  ##N·mm
My1_3 = Vy1_3*h3*l3/(l*N_damp)  ##N·mm
My1_4 = Vy1_4*h4*l3/(l*N_damp)  ##N·mm
My1_5 = Vy1_5*h5*l3/(l*N_damp)  ##N·mm
My1_6 = Vy1_6*h6*l3/(l*N_damp)  ##N·mm
My1_7 = Vy1_7*h7*l3/(l*N_damp)  ##N·mm
My1_8 = Vy1_8*h8*l3/(l*N_damp)  ##N·mm
My1_9 = Vy1_9*h9*l3/(l*N_damp)  ##N·mm
##第二阶段   简化为摩擦段平行  力与第一阶段相同
##各层的设计层间剪力  用上柱剪力  用于子结构设计
Vy2_1 = Vy1_1  ##第一层设计层间剪力 N
Vy2_2 = Vy1_2  ##第二层设计层间剪力 N
Vy2_3 = Vy1_3  ##第三层设计层间剪力 N
Vy2_4 = Vy1_4  ##第四层设计层间剪力 N
Vy2_5 = Vy1_5  ##第五层设计层间剪力 N
Vy2_6 = Vy1_6  ##第六层设计层间剪力 N
Vy2_7 = Vy1_7
Vy2_8 = Vy1_8
Vy2_9 = Vy1_9
##各层的阻尼器弯矩值
My2_1 = My1_1 ##N·mm
My2_2 = My1_2  ##N·mm
My2_3 = My1_3  ##N·mm
My2_4 = My1_4  ##N·mm
My2_5 = My1_5  ##N·mm
My2_6 = My1_6  ##N·mm
My2_7 = My1_7
My2_8 = My1_8
My2_9 = My1_9
##第三阶段
###各层的侧向力分布
Fy3_1 = Cv1*Vy3  ##第一层侧向力     N
Fy3_2 = Cv2*Vy3  ##第二层侧向力     N
Fy3_3 = Cv3*Vy3  ##第三层侧向力     N
Fy3_4 = Cv4*Vy3  ##第四层侧向力     N
Fy3_5 = Cv5*Vy3  ##第五层侧向力     N
Fy3_6 = Cv6*Vy3  ##第六层侧向力     N
Fy3_7 = Cv7*Vy3
Fy3_8 = Cv8*Vy3
Fy3_9 = Cv9*Vy3
##各层的设计层间剪力  用上柱剪力  用于子结构设计
Vy3_1 = Fy3_1+Fy3_2+Fy3_3+Fy3_4+Fy3_5+Fy3_6+Fy3_7+Fy3_8+Fy3_9  ##第一层设计层间剪力 N
Vy3_2 = Fy3_2+Fy3_3+Fy3_4+Fy3_5+Fy3_6+Fy3_7+Fy3_8+Fy3_9  ##第二层设计层间剪力 N
Vy3_3 = Fy3_3+Fy3_4+Fy3_5+Fy3_6+Fy3_7+Fy3_8+Fy3_9  ##第三层设计层间剪力 N
Vy3_4 = Fy3_4+Fy3_5+Fy3_6+Fy3_7+Fy3_8+Fy3_9
Vy3_5 = Fy3_5+Fy3_6+Fy3_7+Fy3_8+Fy3_9
Vy3_6 = Fy3_6+Fy3_7+Fy3_8+Fy3_9
Vy3_7 = Fy3_7+Fy3_8+Fy3_9
Vy3_8 = Fy3_8+Fy3_9
Vy3_9 = Fy3_9
##各层的阻尼器弯矩值
My3_1 = Vy3_1*h1*l3/(l*N_damp) ##N·mm
My3_2 = Vy3_2*h2*l3/(l*N_damp)  ##N·mm
My3_3 = Vy3_3*h3*l3/(l*N_damp)  ##N·mm
My3_4 = Vy3_4*h4*l3/(l*N_damp)  ##N·mm
My3_5 = Vy3_5*h5*l3/(l*N_damp)  ##N·mm
My3_6 = Vy3_6*h6*l3/(l*N_damp)  ##N·mm
My3_7 = Vy3_7*h7*l3/(l*N_damp)  ##N·mm
My3_8 = Vy3_8*h8*l3/(l*N_damp)  ##N·mm
My3_9 = Vy3_9*h9*l3/(l*N_damp)  ##N·mm
##第四阶段
###各层的侧向力分布
Fy4_1 = Cv1*Vy4  ##第一层侧向力     N
Fy4_2 = Cv2*Vy4  ##第二层侧向力     N
Fy4_3 = Cv3*Vy4  ##第三层侧向力     N
Fy4_4 = Cv4*Vy4  ##第四层侧向力     N
Fy4_5 = Cv5*Vy4  ##第五层侧向力     N
Fy4_6 = Cv6*Vy4  ##第六层侧向力     N
Fy4_7 = Cv7*Vy4
Fy4_8 = Cv8*Vy4
Fy4_9 = Cv9*Vy4
##各层的设计层间剪力  用上柱剪力  用于子结构设计
Vy4_1 = Fy4_1+Fy4_2+Fy4_3+Fy4_4+Fy4_5+Fy4_6+Fy4_7+Fy4_8+Fy4_9  ##第一层设计层间剪力 N
Vy4_2 = Fy4_2+Fy4_3+Fy4_4+Fy4_5+Fy4_6+Fy4_7+Fy4_8+Fy4_9  ##第二层设计层间剪力 N
Vy4_3 = Fy4_3+Fy4_4+Fy4_5+Fy4_6+Fy4_7+Fy4_8+Fy4_9  ##第三层设计层间剪力 N
Vy4_4 = Fy4_4+Fy4_5+Fy4_6+Fy4_7+Fy4_8+Fy4_9
Vy4_5 = Fy4_5+Fy4_6+Fy4_7+Fy4_8+Fy4_9
Vy4_6 = Fy4_6+Fy4_7+Fy4_8+Fy4_9
Vy4_7 = Fy4_7+Fy4_8+Fy4_9
Vy4_8 = Fy4_8+Fy4_9
Vy4_9 = Fy4_9
##各层的单个阻尼器弯矩值
My4_1 = Vy4_1*h1*l3/(l*N_damp) ##N·mm
My4_2 = Vy4_2*h2*l3/(l*N_damp)  ##N·mm
My4_3 = Vy4_3*h3*l3/(l*N_damp)  ##N·mm
My4_4 = Vy4_4*h4*l3/(l*N_damp)  ##N·mm
My4_5 = Vy4_5*h5*l3/(l*N_damp)  ##N·mm
My4_6 = Vy4_6*h6*l3/(l*N_damp)  ##N·mm
My4_7 = Vy4_7*h7*l3/(l*N_damp)  ##N·mm
My4_8 = Vy4_8*h8*l3/(l*N_damp)  ##N·mm
My4_9 = Vy4_9*h9*l3/(l*N_damp)  ##N·mm
#########
##每层分配的塑性能量
#########
Ep1 = ((beta1)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第一层分配的塑性能量  N·mm
Ep2 = ((beta2)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第二层分配的塑性能量
Ep3 = ((beta3)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第三层分配的塑性能量
Ep4 = ((beta4)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第三层分配的塑性能量
Ep5 = ((beta5)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第三层分配的塑性能量
Ep6 = ((beta6)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep  ##第三层分配的塑性能量
Ep7 = ((beta7)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep
Ep8 = ((beta8)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep
Ep9 = ((beta9)/(beta1+beta2+beta3+beta4+beta5+beta6+beta7+beta8+beta9))*Ep
# print(Ep1,Ep2,Ep3)
####每层阻尼器能提供的塑性能  M*转角
##阻尼器转角转换   假设层间位移角沿高度均匀
ro1 = l*theta1_/(l3*100)  ##rad
ro2 = l*theta2_/(l3*100)
ro3 = l*theta3_/(l3*100)
ro4 = l*theta4_/(l3*100)
#print(ro1,ro2,ro3,ro4)
Ep1_damp = N_damp*(My1_1*(0.5*ro2+0.5*ro3-ro1)+My3_1*(0.5*ro4-0.5*ro2)+My4_1*(0.5*ro4-0.5*ro3))  ##N·mm·rad
Ep2_damp = N_damp*(My1_2*(0.5*ro2+0.5*ro3-ro1)+My3_2*(0.5*ro4-0.5*ro2)+My4_2*(0.5*ro4-0.5*ro3))
Ep3_damp = N_damp*(My1_3*(0.5*ro2+0.5*ro3-ro1)+My3_3*(0.5*ro4-0.5*ro2)+My4_3*(0.5*ro4-0.5*ro3))
Ep4_damp = N_damp*(My1_4*(0.5*ro2+0.5*ro3-ro1)+My3_4*(0.5*ro4-0.5*ro2)+My4_4*(0.5*ro4-0.5*ro3))
Ep5_damp = N_damp*(My1_5*(0.5*ro2+0.5*ro3-ro1)+My3_5*(0.5*ro4-0.5*ro2)+My4_5*(0.5*ro4-0.5*ro3))
Ep6_damp = N_damp*(My1_6*(0.5*ro2+0.5*ro3-ro1)+My3_6*(0.5*ro4-0.5*ro2)+My4_6*(0.5*ro4-0.5*ro3))
Ep7_damp = N_damp*(My1_7*(0.5*ro2+0.5*ro3-ro1)+My3_7*(0.5*ro4-0.5*ro2)+My4_7*(0.5*ro4-0.5*ro3))
Ep8_damp = N_damp*(My1_8*(0.5*ro2+0.5*ro3-ro1)+My3_8*(0.5*ro4-0.5*ro2)+My4_8*(0.5*ro4-0.5*ro3))
Ep9_damp = N_damp*(My1_9*(0.5*ro2+0.5*ro3-ro1)+My3_9*(0.5*ro4-0.5*ro2)+My4_9*(0.5*ro4-0.5*ro3))
# print(Ep1_damp,Ep2_damp,Ep3_damp)

####初设的阻尼器的塑性耗能不足  提升阻尼器承载力来满足塑性耗能需求
f1_damp = Ep1/Ep1_damp
f2_damp = Ep2/Ep2_damp
f3_damp = Ep3/Ep3_damp
f4_damp = Ep4/Ep4_damp
f5_damp = Ep5/Ep5_damp
f6_damp = Ep6/Ep6_damp
f7_damp = Ep7/Ep7_damp
f8_damp = Ep8/Ep8_damp
f9_damp = Ep9/Ep9_damp
if f1_damp<1:
    f1_damp =1
if f2_damp<1:
    f2_damp =1
if f3_damp<1:
    f3_damp =1
if f4_damp<1:
    f4_damp =1
if f5_damp<1:
    f5_damp =1
if f6_damp<1:
    f6_damp =1
if f7_damp<1:
    f7_damp =1
if f8_damp<1:
    f8_damp =1
if f9_damp<1:
    f9_damp =1
Ep1_damp = f1_damp*N_damp*(My1_1*(0.5*ro2+0.5*ro3-ro1)+My3_1*(0.5*ro4-0.5*ro2)+My4_1*(0.5*ro4-0.5*ro3))  ##N·mm·rad
Ep2_damp = f2_damp*N_damp*(My1_2*(0.5*ro2+0.5*ro3-ro1)+My3_2*(0.5*ro4-0.5*ro2)+My4_2*(0.5*ro4-0.5*ro3))
Ep3_damp = f3_damp*N_damp*(My1_3*(0.5*ro2+0.5*ro3-ro1)+My3_3*(0.5*ro4-0.5*ro2)+My4_3*(0.5*ro4-0.5*ro3))
Ep4_damp = f4_damp*N_damp*(My1_4*(0.5*ro2+0.5*ro3-ro1)+My3_4*(0.5*ro4-0.5*ro2)+My4_4*(0.5*ro4-0.5*ro3))
Ep5_damp = f5_damp*N_damp*(My1_5*(0.5*ro2+0.5*ro3-ro1)+My3_5*(0.5*ro4-0.5*ro2)+My4_5*(0.5*ro4-0.5*ro3))
Ep6_damp = f6_damp*N_damp*(My1_6*(0.5*ro2+0.5*ro3-ro1)+My3_6*(0.5*ro4-0.5*ro2)+My4_6*(0.5*ro4-0.5*ro3))
Ep7_damp = f7_damp*N_damp*(My1_7*(0.5*ro2+0.5*ro3-ro1)+My3_7*(0.5*ro4-0.5*ro2)+My4_7*(0.5*ro4-0.5*ro3))
Ep8_damp = f8_damp*N_damp*(My1_8*(0.5*ro2+0.5*ro3-ro1)+My3_8*(0.5*ro4-0.5*ro2)+My4_8*(0.5*ro4-0.5*ro3))
Ep9_damp = f9_damp*N_damp*(My1_9*(0.5*ro2+0.5*ro3-ro1)+My3_9*(0.5*ro4-0.5*ro2)+My4_9*(0.5*ro4-0.5*ro3))
# print(f1_damp,f2_damp,f3_damp,f4_damp,f5_damp,f6_damp,f7_damp,f8_damp,f9_damp)

###提升之后的阻尼器各阶段承载力 刚度  滑移角度 参数
s = ro2-ro1  ##阻尼器摩擦段滑移角度  假设每层都一样
###第一层
My1_1_d = My1_1*f1_damp  #第一阶段     ##N·mm
My2_1_d = My1_1_d   #第二阶段
My3_1_d = My3_1*f1_damp #第三阶段
My4_1_d = My4_1*f1_damp #第四阶段
k1_1 = My1_1_d/ro1  ##N·mm/rad
k2_1 = 0
k3_1 = (My3_1_d-My1_1_d)/(ro3-ro2)
k4_1 = (My4_1_d-My3_1_d)/(ro4-ro3)
###第二层
My1_2_d = My1_2*f2_damp  #第一阶段     ##N·mm
My2_2_d = My1_2_d   #第二阶段
My3_2_d = My3_2*f2_damp #第三阶段
My4_2_d = My4_2*f2_damp #第四阶段
k1_2 = My1_2_d/ro1  ##N·mm/rad
k2_2 = 0
k3_2 = (My3_2_d-My1_2_d)/(ro3-ro2)
k4_2 = (My4_2_d-My3_2_d)/(ro4-ro3)
###第三层
My1_3_d = My1_3*f3_damp  #第一阶段     ##N·mm
My2_3_d = My1_3_d   #第二阶段
My3_3_d = My3_3*f3_damp #第三阶段
My4_3_d = My4_3*f3_damp #第四阶段
k1_3 = My1_3_d/ro1  ##N·mm/rad
k2_3 = 0
k3_3 = (My3_3_d-My1_3_d)/(ro3-ro2)
k4_3 = (My4_3_d-My3_3_d)/(ro4-ro3)
###第四层
My1_4_d = My1_4*f4_damp  #第一阶段     ##N·mm
My2_4_d = My1_4_d   #第二阶段
My3_4_d = My3_4*f4_damp #第三阶段
My4_4_d = My4_4*f4_damp #第四阶段
k1_4 = My1_4_d/ro1  ##N·mm/rad
k2_4 = 0
k3_4 = (My3_4_d-My1_4_d)/(ro3-ro2)
k4_4 = (My4_4_d-My3_4_d)/(ro4-ro3)
###第五层
My1_5_d = My1_5*f5_damp  #第一阶段     ##N·mm
My2_5_d = My1_5_d  #第二阶段
My3_5_d = My3_5*f5_damp #第三阶段
My4_5_d = My4_5*f5_damp #第四阶段
k1_5 = My1_5_d/ro1  ##N·mm/rad
k2_5 = 0
k3_5 = (My3_5_d-My1_5_d)/(ro3-ro2)
k4_5 = (My4_5_d-My3_5_d)/(ro4-ro3)
###第六层
My1_6_d = My1_6*f6_damp  #第一阶段     ##N·mm
My2_6_d = My1_6_d   #第二阶段
My3_6_d = My3_6*f6_damp #第三阶段
My4_6_d = My4_6*f6_damp #第四阶段
k1_6 = My1_6_d/ro1  ##N·mm/rad
k2_6 = 0
k3_6 = (My3_6_d-My1_6_d)/(ro3-ro2)
k4_6 = (My4_6_d-My3_6_d)/(ro4-ro3)
###第七层
My1_7_d = My1_7*f7_damp  #第一阶段     ##N·mm
My2_7_d = My1_7_d   #第二阶段
My3_7_d = My3_7*f7_damp #第三阶段
My4_7_d = My4_7*f7_damp #第四阶段
k1_7 = My1_7_d/ro1  ##N·mm/rad
k2_7 = 0
k3_7 = (My3_7_d-My1_7_d)/(ro3-ro2)
k4_7 = (My4_7_d-My3_7_d)/(ro4-ro3)
###第八层
My1_8_d = My1_8*f8_damp  #第一阶段     ##N·mm
My2_8_d = My1_8_d   #第二阶段
My3_8_d = My3_8*f8_damp #第三阶段
My4_8_d = My4_8*f8_damp #第四阶段
k1_8 = My1_8_d/ro1  ##N·mm/rad
k2_8 = 0
k3_8 = (My3_8_d-My1_8_d)/(ro3-ro2)
k4_8 = (My4_8_d-My3_8_d)/(ro4-ro3)
###第九层
My1_9_d = My1_9*f9_damp  #第一阶段     ##N·mm
My2_9_d = My1_9_d   #第二阶段
My3_9_d = My3_9*f9_damp #第三阶段
My4_9_d = My4_9*f9_damp #第四阶段
k1_9 = My1_9_d/ro1  ##N·mm/rad
k2_9 = 0
k3_9 = (My3_9_d-My1_9_d)/(ro3-ro2)
k4_9 = (My4_9_d-My3_9_d)/(ro4-ro3)
# print('F1_damp=',{'Kf':k1_1,'Kr':k3_1 ,'Kp':k4_1,'Mf':My1_1_d,'Mr':My3_1_d,'s':s})
# print('F2_damp=',{'Kf':k1_2,'Kr':k3_2 ,'Kp':k4_2,'Mf':My1_2_d,'Mr':My3_2_d,'s':s})
# print('F3_damp=',{'Kf':k1_3,'Kr':k3_3 ,'Kp':k4_3,'Mf':My1_3_d,'Mr':My3_3_d,'s':s})
# print('F4_damp=',{'Kf':k1_4,'Kr':k3_4 ,'Kp':k4_4,'Mf':My1_4_d,'Mr':My3_4_d,'s':s})
# print('F5_damp=',{'Kf':k1_5,'Kr':k3_5 ,'Kp':k4_5,'Mf':My1_5_d,'Mr':My3_5_d,'s':s})
# print('F6_damp=',{'Kf':k1_6,'Kr':k3_6 ,'Kp':k4_6,'Mf':My1_6_d,'Mr':My3_6_d,'s':s})
# print('F7_damp=',{'Kf':k1_7,'Kr':k3_7 ,'Kp':k4_7,'Mf':My1_7_d,'Mr':My3_7_d,'s':s})
# print('F8_damp=',{'Kf':k1_8,'Kr':k3_8 ,'Kp':k4_8,'Mf':My1_8_d,'Mr':My3_8_d,'s':s})
# print('F9_damp=',{'Kf':k1_9,'Kr':k3_9 ,'Kp':k4_9,'Mf':My1_9_d,'Mr':My3_9_d,'s':s})
# print('Mp_list =',[My4_1_d,My4_2_d,My4_3_d,My4_4_d,My4_5_d,My4_6_d,My4_7_d,My4_8_d,My4_9_d])

# 示例列表数据
listF1 = [My1_1_d/10**6, My3_1_d/10**6, My4_1_d/10**6,k1_1/10**6,k3_1/10**6,k4_1/10**6,s]
listF2 = [My1_2_d/10**6, My3_2_d/10**6, My4_2_d/10**6,k1_2/10**6,k3_2/10**6,k4_2/10**6,s]
listF3 = [My1_3_d/10**6, My3_3_d/10**6, My4_3_d/10**6,k1_3/10**6,k3_3/10**6,k4_3/10**6,s]
listF4 = [My1_4_d/10**6, My3_4_d/10**6, My4_4_d/10**6,k1_4/10**6,k3_4/10**6,k4_4/10**6,s]
listF5 = [My1_5_d/10**6, My3_5_d/10**6, My4_5_d/10**6,k1_5/10**6,k3_5/10**6,k4_5/10**6,s]
listF6 = [My1_6_d/10**6, My3_6_d/10**6, My4_6_d/10**6,k1_6/10**6,k3_6/10**6,k4_6/10**6,s]
listF7 = [My1_7_d/10**6, My3_7_d/10**6, My4_7_d/10**6,k1_7/10**6,k3_7/10**6,k4_7/10**6,s]
listF8 = [My1_8_d/10**6, My3_8_d/10**6, My4_8_d/10**6,k1_8/10**6,k3_8/10**6,k4_8/10**6,s]
listF9 = [My1_9_d/10**6, My3_9_d/10**6, My4_9_d/10**6,k1_9/10**6,k3_9/10**6,k4_9/10**6,s]

###其他截面设计  接近目标位移角
Vy = 4*3.14159**2*M*theta1_*(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6)*10**(-3)/(T**2)
Mpc =(Vy4/5)*1.1*H1/4
Wp1=Mpc/345
Wp2=2*Mpc/345
# print('Mpc=',Mpc)
##试配柱截面
print('Wp1=',Wp1)
print('Wp2=',Wp2)
Mpc1 =7108569.1280000005*345
Mpc2 =14191857.035999998*345
Mpc_all = 2*Mpc1+4*Mpc2
Mdampc = My4_1_d+My4_2_d+My4_3_d+My4_4_d+My4_5_d+My4_6_d+My4_7_d+My4_8_d+My4_9_d
# print('Mpc1=',Mpc1,'Mpc2=',Mpc2)
Vp4 = (Mpc_all+20*(l/l3)*Mdampc)/(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6+Cv7*H7+Cv8*H8+Cv9*H9)
print('V4=',Vp4/1000)

###高度
h_list = [1400+1333+1400,4200,4200,4200,4200,4200,4200,4200,4200-1400]
h1_list = [1400,1400,1400,1400,1400,1400,1400,1400,0]
h2_list = [1400,1400,1400,1400,1400,1400,1400,1400,1400]
h3_list = [1333,1400,1400,1400,1400,1400,1400,1400,1400]
###ST1
I1_list_ST1 = [401717574.0, 401717574.0, 368590885.3333333, 368590885.3333333, 347257552.0, 347257552.0, 265930496.0, 265930496.0, 265930496.0]
A1_list_ST1 = [18402.0, 18402.0, 16444.0, 16444.0, 14844.0, 14844.0, 14928, 14928, 14928]
I3_list_ST1 = [401717574.0, 401717574.0, 368590885.3333333, 368590885.3333333, 347257552.0, 347257552.0, 265930496.0, 265930496.0, 265930496.0]
A3_list_ST1 = [18402.0, 18402.0, 16444.0, 16444.0, 14844.0, 14844.0, 14928, 14928, 14928]
A5_list_ST1 = [12160, 12160, 9600, 9600, 11085.0, 11085.0, 10165.0, 10165.0, 10165.0]
I7_list_ST1 = I8_list_ST1 = [1244716225.3029337, 1244716225.3029337, 1097587428.6474004, 1097587428.6474004, 992326725.6876003, 992326725.6876003, 889307450.5031998, 889307450.5031998, 889307450.5031998]
A7_list_ST1 = A8_list_ST1 = [44002.72000000001, 44002.72000000001, 39722.22, 39722.22, 36434.280000000006, 36434.280000000006, 33267.24, 33267.24, 33267.24]
I7_list_ST2 = I8_list_ST2 = [2736976678.4375997, 2736976678.4375997, 2496854872.2779994, 2496854872.2779994, 2256366979.5506663, 2256366979.5506663, 2040518269.1624668, 2040518269.1624668, 2040518269.1624668]
A7_list_ST2 = A8_list_ST2 = [80603.28, 80603.28, 75294.59999999999, 75294.59999999999, 69945.2, 69945.2, 64701.86, 64701.86, 64701.86]
I2_list_ST1 =I1_list_ST1
A2_list_ST1 =A1_list_ST1
A4_list_ST1 =A3_list_ST1
theta1 = 0.28
###阻尼器
F1_damp= {'Kf': k1_1, 'Kr': k3_1 , 'Kp': k4_1, 'Mf': My1_1_d, 'Mr': My3_1_d, 's': s}
F2_damp= {'Kf': k1_2, 'Kr': k3_2 , 'Kp': k4_2, 'Mf': My1_2_d, 'Mr': My3_2_d, 's': s}
F3_damp= {'Kf': k1_3, 'Kr': k3_3 , 'Kp': k4_3, 'Mf': My1_3_d, 'Mr': My3_3_d, 's': s}
F4_damp= {'Kf': k1_4, 'Kr': k3_4 , 'Kp': k4_4, 'Mf': My1_4_d, 'Mr': My3_4_d, 's': s}
F5_damp= {'Kf': k1_5, 'Kr': k3_5 , 'Kp': k4_5, 'Mf': My1_5_d, 'Mr': My3_5_d, 's': s}
F6_damp= {'Kf': k1_6, 'Kr': k3_6 , 'Kp': k4_6, 'Mf': My1_6_d, 'Mr': My3_6_d, 's': s}
F7_damp= {'Kf': k1_7, 'Kr': k3_7 , 'Kp': k4_7, 'Mf': My1_7_d, 'Mr': My3_7_d, 's': s}
F8_damp= {'Kf': k1_8, 'Kr': k3_8 , 'Kp': k4_8, 'Mf': My1_8_d, 'Mr': My3_8_d, 's': s}
F9_damp= {'Kf': k1_9, 'Kr': k3_9 , 'Kp': k4_9, 'Mf': My1_9_d, 'Mr': My3_9_d, 's': s}
Mp_list = [My4_1_d,My4_2_d,My4_3_d,My4_4_d,My4_5_d,My4_6_d,My4_7_d,My4_8_d,My4_9_d]
theta_list = []
K_list =[] 
beishu_list = [1,1,1,1,1,1,1,1,1]
beishu_list1 =[1.841436070420347, 1.8496528594637949, 1.926910173758589, 1.882636736792274, 1.8705281381236316, 1.7884358233630087, 1.7506604828131946, 1.601882191307821, 1.3922345795239743]
beishu_list2 =[1.3518515220557938, 1.357483561442436, 1.4115161212296017, 1.3803187911629855, 1.3718942494328168, 1.316094206820991, 1.291245823817751, 1.1993096551372655, 1.0903807530316396]
beishu_list=np.multiply(beishu_list1, beishu_list2)
beishu_list3 =[1.2004127717388846, 1.2049397856370525, 1.2494087495560875, 1.2235119240626477, 1.2166205840581459, 1.1722079144566444, 1.1532035604263389, 1.0881544875350369, 1.0265913429855777]
beishu_list=np.multiply(beishu_list, beishu_list3)
beishu_kp =0.393
# print(beishu_list[0],'\n',beishu_list[1],'\n',beishu_list[2],'\n',beishu_list[3],'\n',beishu_list[4],'\n',beishu_list[5],'\n',beishu_list[6],'\n',beishu_list[7],'\n',beishu_list[8])
for Snum in range(1,10): 
    ######ST1公式计算
    h =h_list[Snum-1]
    h1=h1_list[Snum-1]
    h2=h2_list[Snum-1]
    h3=h3_list[Snum-1]

    l =4600
    l1=1675
    l2=1675
    l3=1250

    I1=I1_list_ST1[Snum-1]
    I2=I2_list_ST1[Snum-1]
    I3=I3_list_ST1[Snum-1]
    I7=I7_list_ST1[Snum-1]
    I8=I8_list_ST1[Snum-1]

    A1=A1_list_ST1[Snum-1]
    A3=A3_list_ST1[Snum-1]
    A4=A4_list_ST1[Snum-1]
    A5=A5_list_ST1[Snum-1]
    A7=A7_list_ST1[Snum-1]
    A8=A8_list_ST1[Snum-1]
    E=2.0*10**5
    u = 0.3
    G = E/(2*(1+u))
    ###阻尼器参数
    F_damp_list =[F1_damp,F2_damp,F3_damp,F4_damp,F5_damp,F6_damp,F7_damp,F8_damp,F9_damp] 
    F_damp = F_damp_list[Snum-1]
    k_damp_e = F_damp['Kf']*beishu_list[Snum-1]
    k_damp_y = F_damp['Kr']*beishu_list[Snum-1]
    k_damp_p = F_damp['Kp']*beishu_list[Snum-1]*beishu_kp
    Me = F_damp['Mf']
    My = F_damp['Mr']
    Mp =Mp_list[Snum-1]##[198490776.3264199,148066848.88500822,136517660.20492318,119063072.3385962,94294085.98531535,58562974.69278574]
    s = F_damp['s']
    ###系数
    C1 = h2/(3*E*I2)+l2/(3*E*I3)+l2/(E*A3*h2**2)+(l2**2+h2**2)**(3/2)/(E*A5*l2**2*h2**2)
    C2=h2/(6*E*I2)-l2/(E*A3*h2**2)-(l2**2+h2**2)**(3/2)/(E*A5*l2**2*h2**2)
    C3=h*(l2+l3)*(h2**2+l2**2)**(3/2)/(E*A5*l*l2**2*h2**2)
    C4=l2*l3/(3*E*I3)
    X1 = h/(2*l)
    X2 = (C3+X1*C4)/(C2-C1)
    X3=-X2
    F1 = math.sqrt(l2**2+h2**2)/(l2*h2)
    F2 = (h*(l2+l3)*math.sqrt(l2**2+h2**2))/(l*l2*h2)
    F3 = h*(l2+l3)/(l*h2)
    F4 = h*math.sqrt(h2**2+l1**2)/(l*h2)
    ###位移
    deta_M = (h**2*l3**3)/(6*E*I1*l**2)+(l2*l3*h)*(h*l3/(2*l)-X3)/(3*E*I3*l)+(h1**2*h2/3-h1*h2*h3/3+h2*h3**2/3+h3**3/3)/(E*I7)+h1**3/(3*E*I8)
    deta_Q = l1*h**2/(4*G*A1*l**2)+(h3+(h1+h3)**2/h2)/(G*A7)+h1/(G*A8)
    deta_N = F3**2*l1/(E*A3)+l1*(F3**2+((h1+h3)/h2+h/l)**2)/(E*A4)+((F2+F1*X2-F1*X3)*F2*math.sqrt(h2**2+l2**2)+F4**2*math.sqrt(h2**2+l1**2))/(E*A5)
    deta_damp_e = h**2*l3**2/(2*l**2*k_damp_e)
    deta_damp_y = h**2*l3**2/(2*l**2*k_damp_y)
    deta_damp_p = h**2*l3**2/(2*l**2*k_damp_p)
    ###子结构刚度
    K_STMF1_e = h/(deta_M+deta_Q+deta_N+deta_damp_e)
    K_STMF1_y = h/(deta_M+deta_Q+deta_N+deta_damp_y)
    K_STMF1_p = h/(deta_M+deta_Q+deta_N+deta_damp_p)
    ####子结构滑动位移角
    theta1_d = s*l3/l
    ###子结构柱剪力
    V_STMF1_e=2*l*Me/(h*l3)
    V_STMF1_y=2*l*My/(h*l3)
    V_STMF1_p=2*l*Mp/(h*l3)
    theta1_e = V_STMF1_e/K_STMF1_e
    theta1_s = theta1_e+theta1_d
    theta1_y = theta1_s+(V_STMF1_y-V_STMF1_e)/K_STMF1_y
    theta1_p = theta1_y+(V_STMF1_p-V_STMF1_y)/K_STMF1_p###自定义极限加载位移角
    # print('######ST1#####')
    # print('K_STMF1_e=',K_STMF1_e,'K_STMF1_y=',K_STMF1_y,'K_STMF1_p=',K_STMF1_p)
    # print('deta_M=',deta_M,'deta_Q=',deta_Q,'deta_N=',deta_N,'deta_damp_e=',deta_damp_e,'deta_M13',(h**2*l3**3)/(6*E*I1*l**2)+(l2*l3*h)*(h*l3/(2*l)-X3)/(3*E*I3*l),'deta_M78=',(h1**2*h2/3-h1*h2*h3/3+h2*h3**2/3+h3**3/3)/(E*I7)+h1**3/(3*E*I8))
    # print('point0',0,0)
    # print('point1',theta1_e*100,V_STMF1_e)
    # print('point2',theta1_s*100,V_STMF1_e)
    # print('point3',theta1_y*100,V_STMF1_y)
    # print('point4',theta1_p*100,V_STMF1_p)
    # print(deta_M+deta_Q+deta_N+deta_damp_e)
    # print('x_duibi =',[0,theta1_e*100,theta1_s*100,theta1_y*100,theta1_p*100])
    # print('y_duibi =' ,[0,V_STMF1_e/1000,V_STMF1_e/1000,V_STMF1_y/1000,V_STMF1_p/1000])
    # print('V1=',l*Me*2/(h*l3),'V2=',l*My*2/(h*l3),'V3=',l*(((0.015-theta1_y)*l3/l)*k_damp_p+My)*2/(h*l3),theta1_y)
    ######ST2公式计算

    I7=I7_list_ST2[Snum-1]
    I8=I8_list_ST2[Snum-1]
    A7=A7_list_ST2[Snum-1]
    A8=A8_list_ST2[Snum-1]

    ###系数
    C1 = h2/(3*E*I2)+l2/(3*E*I3)+l2/(E*A3*h2**2)+(l2**2+h2**2)**(3/2)/(E*A5*l2**2*h2**2)
    C2 =h2/(6*E*I2)-l2/(E*A3*h2**2)-(l2**2+h2**2)**(3/2)/(E*A5*l2**2*h2**2)
    C3 =h*(l2+l3)*(h2**2+l2**2)**(3/2)/(E*A5*l*l2**2*h2**2)
    C4 =l2*l3/(3*E*I3)
    X1 = h/(2*l)
    X2 = (C3+X1*C4)/(C2-C1)
    X3 =-X2
    F1 = math.sqrt(l2**2+h2**2)/(l2*h2)
    F2 = (h*(l2+l3)*math.sqrt(l2**2+h2**2))/(l*l2*h2)
    F3 = h*(l2+l3)/(l*h2)
    F4 = h*math.sqrt(h2**2+l1**2)/(l*h2)
    ###位移
    deta_M=(h**2*l3**3)/(12*E*I1*l**2)+(l2*l3*h)*(h*l3/(2*l)-X3)/(6*E*I3*l)+(h1**2*h2/3-h1*h2*h3/3+h2*h3**2/3+h3**3/3)/(E*I7)+h1**3/(3*E*I8)
    deta_Q=l1*h**2/(8*G*A1*l**2)+(h3+(h1+h3)**2/h2)/(G*A7)+h1/(G*A8)
    deta_N = F3**2*l1/(2*E*A3)+l1*(F3**2+((h1+h3)/h2+h/l)**2)/(2*E*A4)+((F2+F1*X2-F1*X3)*F2*math.sqrt(h2**2+l2**2)+F4**2*math.sqrt(h2**2+l1**2))/(2*E*A5)
    deta_damp_e = h**2*l3**2/(4*l**2*k_damp_e)
    deta_damp_y = h**2*l3**2/(4*l**2*k_damp_y)
    deta_damp_p = h**2*l3**2/(4*l**2*k_damp_p)
    ###子结构刚度
    K_STMF2_e = h/(deta_M+deta_Q+deta_N+deta_damp_e)
    K_STMF2_y = h/(deta_M+deta_Q+deta_N+deta_damp_y)
    K_STMF2_p = h/(deta_M+deta_Q+deta_N+deta_damp_p)
    ####子结构滑动位移角
    theta2_d = s*l3/l
    ###子结构柱剪力
    V_STMF2_e=4*l*Me/(h*l3)
    V_STMF2_y=4*l*My/(h*l3)
    V_STMF2_p=4*l*Mp/(h*l3)
    theta2_e = V_STMF2_e/K_STMF2_e
    theta2_s = theta2_e+theta2_d
    theta2_y = theta2_s+(V_STMF2_y-V_STMF2_e)/K_STMF2_y
    theta2_p = theta2_y+(V_STMF2_p-V_STMF2_y)/K_STMF2_p###自定义极限加载位移角

    # print('######ST2#####')
    # print('deta_M=',deta_M,'deta_Q=',deta_Q,'deta_N=',deta_N,'deta_damp_e=',deta_damp_e,'deta_M13=',(h**2*l3**3)/(12*E*I1*l**2)+(l2*l3*h)*(h*l3/(2*l)-X3)/(6*E*I3*l),'deta_M78=',(h1**2*h2/3-h1*h2*h3/3+h2*h3**2/3+h3**3/3)/(E*I7)+h1**3/(3*E*I8))
    # print(deta_M+deta_Q+deta_N+deta_damp_e)
    # print('point0',0,0)
    # print('point1',theta2_e*100,V_STMF2_e)
    # print('point2',theta2_s*100,V_STMF2_e)
    # print('point3',theta2_y*100,V_STMF2_y)
    # print('point4',theta2_p*100,V_STMF2_p)
    # print('x_duibi =',[0,theta2_e*100,theta2_s*100,theta2_y*100,theta2_p*100])
    # print('y_duibi =' ,[0,V_STMF2_e/1000,V_STMF2_e/1000,V_STMF2_y/1000,V_STMF2_p/1000])
    #########中间层
    ##子结构数量
    N_ST1 = 2
    N_ST2 = 4
    ##中间层刚度
    K_mid_e = N_ST1*K_STMF1_e+N_ST2*K_STMF2_e
    K_mid_y = N_ST1*K_STMF1_y+N_ST2*K_STMF2_y
    K_mid_p = N_ST1*K_STMF1_p+N_ST2*K_STMF2_p
    theta_mid_e = max(theta1_e,theta2_e)
    theta_mid_s = max(theta1_s,theta2_s)
    theta_mid_y = max(theta1_y,theta2_y)
    theta_mid_p = max(theta1_p,theta2_p)
    # theta_mid_e = theta1_e
    # theta_mid_s = theta1_s
    # theta_mid_y = theta1_y
    V_mid_e = K_mid_e*theta_mid_e
    V_mid_y = K_mid_y*(theta_mid_y-theta_mid_s)+V_mid_e
    V_mid_p = K_mid_p*(theta_mid_p-theta_mid_y)+V_mid_y
    # print('######ST_mid#####')
    # print(1/K_mid_e)
    # print(K_mid_e,K_mid_y,K_mid_p,K_mid_p/K_mid_y)
    # print('point0',0,0)
    # print('point1',theta_mid_e*100,V_mid_e/1000)##(%,kN)
    # print('point2',theta_mid_s*100,V_mid_e/1000)
    # print('point3',theta_mid_y*100,V_mid_y/1000)
    # print('point4',theta_mid_p*100,V_mid_p/1000)
    # print('Floor',Snum)
    # print('x_duibi = ',[0,theta_mid_e*100,theta_mid_s*100,theta_mid_y*100,theta_mid_p*100])
    # print('y_duibi =' ,[0,V_mid_e/1000,V_mid_e/1000,V_mid_y/1000,V_mid_p/1000])
    # print(K_mid_e,K_mid_y,K_mid_p)
    K_list.append(theta_mid_e*100/theta1)
    theta_list.append([0,theta_mid_e*100,theta_mid_s*100,theta_mid_y*100,theta_mid_p*100])

# print(K_list)
theta_0=(theta_list[0][0]+theta_list[1][0]+theta_list[2][0]+theta_list[3][0]+theta_list[4][0]+theta_list[5][0]+theta_list[6][0]+theta_list[7][0]+theta_list[8][0])/9
theta_1=(theta_list[0][1]+theta_list[1][1]+theta_list[2][1]+theta_list[3][1]+theta_list[4][1]+theta_list[5][1]+theta_list[6][1]+theta_list[7][1]+theta_list[8][1])/9
theta_2=(theta_list[0][2]+theta_list[1][2]+theta_list[2][2]+theta_list[3][2]+theta_list[4][2]+theta_list[5][2]+theta_list[6][2]+theta_list[7][2]+theta_list[8][2])/9
theta_3=(theta_list[0][3]+theta_list[1][3]+theta_list[2][3]+theta_list[3][3]+theta_list[4][3]+theta_list[5][3]+theta_list[6][3]+theta_list[7][3]+theta_list[8][3])/9
theta_4=(theta_list[0][4]+theta_list[1][4]+theta_list[2][4]+theta_list[3][4]+theta_list[4][4]+theta_list[5][4]+theta_list[6][4]+theta_list[7][4]+theta_list[8][4])/9
print([theta_0,theta_1,theta_2,theta_3,theta_4])
###输出最终阻尼器设计结果 ##单位N mm
######
print('Dampers design information')
print('F1_damp=',{'M1':My1_1_d,'M3':My3_1_d,'M4':My4_1_d,'K1':k1_1*beishu_list[0],'K3':k3_1*beishu_list[0] ,'K4':k4_1*beishu_list[0]*beishu_kp,'S':s})
print('F2_damp=',{'M1':My1_2_d,'M3':My3_2_d,'M4':My4_2_d,'K1':k1_2*beishu_list[1],'K3':k3_2*beishu_list[1] ,'K4':k4_2*beishu_list[1]*beishu_kp,'S':s})
print('F3_damp=',{'M1':My1_3_d,'M3':My3_3_d,'M4':My4_3_d,'K1':k1_3*beishu_list[2],'K3':k3_3*beishu_list[2] ,'K4':k4_3*beishu_list[2]*beishu_kp,'S':s})
print('F4_damp=',{'M1':My1_4_d,'M3':My3_4_d,'M4':My4_4_d,'K1':k1_4*beishu_list[3],'K3':k3_4*beishu_list[3] ,'K4':k4_4*beishu_list[3]*beishu_kp,'S':s})
print('F5_damp=',{'M1':My1_5_d,'M3':My3_5_d,'M4':My4_5_d,'K1':k1_5*beishu_list[4],'K3':k3_5*beishu_list[4] ,'K4':k4_5*beishu_list[4]*beishu_kp,'S':s})
print('F6_damp=',{'M1':My1_6_d,'M3':My3_6_d,'M4':My4_6_d,'K1':k1_6*beishu_list[5],'K3':k3_6*beishu_list[5] ,'K4':k4_6*beishu_list[5]*beishu_kp,'S':s})
print('F7_damp=',{'M1':My1_7_d,'M3':My3_7_d,'M4':My4_7_d,'K1':k1_7*beishu_list[6],'K3':k3_7*beishu_list[6] ,'K4':k4_7*beishu_list[6]*beishu_kp,'S':s})
print('F6_damp=',{'M1':My1_8_d,'M3':My3_8_d,'M4':My4_8_d,'K1':k1_8*beishu_list[7],'K3':k3_8*beishu_list[7] ,'K4':k4_8*beishu_list[7]*beishu_kp,'S':s})
print('F6_damp=',{'M1':My1_9_d,'M3':My3_9_d,'M4':My4_9_d,'K1':k1_9*beishu_list[8],'K3':k3_9*beishu_list[8] ,'K4':k4_9*beishu_list[8]*beishu_kp,'S':s})