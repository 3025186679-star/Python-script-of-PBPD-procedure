import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import os
import pandas as pd
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from scipy.integrate import cumulative_trapezoid
import numpy as np
import joblib
import h5py
from sklearn.inspection import partial_dependence
import shap
import sys
from scipy.io import loadmat
import pickle
import scipy.io as sio
import math
from scipy.optimize import bisect
from scipy.integrate import quad
from scipy.stats import lognorm  # 添加lognorm模块
# 定义 PDF 函数
def pdf(x_gm,ls,lm):
    return (1/(x_gm*ls*np.sqrt(2*3.14159)))*(np.exp(-((np.log(x_gm)-lm)**2)/(2*(ls)**2)))  
# 反推 对应于给定概率水平 p 的x
def find_x_for_probability(p, ls, lm):
    # 直接使用lognorm的分位数函数
    return lognorm.ppf(p, s=ls, scale=np.exp(lm))
def predict(a1,a2,a3,ξ,ξ1,ξ2,μ,T,p):
    ############四折MCE 能量系数
    # 加载模型
    with open("XGBoost_model\\best_xgb_model_biaozhuncha.pkl", 'rb') as f:
        model_biaozhuncha = pickle.load(f)
    with open("XGBoost_model\\best_xgb_model_junzhi.pkl", 'rb') as f:
        model_junzhi = pickle.load(f)
    scaler = joblib.load("XGBoost_model\\scaler_biaozhuncha.pkl")###加载已保存的标准化器
    inputs =[a1,a2,a3,ξ,ξ1,ξ2,μ,T]
    # 将输入转换为 DataFrame
    input_data = pd.DataFrame([inputs], columns=['α1', 'α2', 'α3', 'ξ', 'ξ1', 'ξ2', 'μ','T'])
    # 标准化输入数据
    input_data_scaled = scaler.transform(input_data)
    # 使用模型进行预测
    prediction_biaozhuncha = model_biaozhuncha.predict(input_data_scaled)
    prediction_junzhi = model_junzhi.predict(input_data_scaled)
    # print(prediction_biaozhuncha,prediction_junzhi)
    # print(find_x_for_probability(p,prediction_biaozhuncha,prediction_junzhi))
    gama_MCE_pre=find_x_for_probability(p,prediction_biaozhuncha,prediction_junzhi)#四折MCE预测
    ########二折DBE的能量系数
    # 计算中间参数 
    a_DBE = np.exp(-7.424/ξ1 - 3.051*a1 + 1.065)
    b_DBE = 1/(-0.609*np.sqrt(ξ1) + 0.758*np.sqrt(a1) - 0.363)
    c_DBE = 1/(-1.506/np.log(ξ1) + 0.859/np.log(a1) + 0.526)
    d_DBE = 0.028/ξ1 + 0.025*a1**1.5 - 0.024
    e_DBE = -0.067/ξ1 - 0.090*a1**1.5 + 0.072
    f_DBE = np.exp(-2.094/(ξ1**1.5) - 1.258*a1**1.5 - 0.168)
    # 计算对数均值和标准差
    log_mean_DBE = a_DBE*T**b_DBE + c_DBE
    log_std_DBE = d_DBE*T**2 + e_DBE*T + f_DBE
    # 生成数据点
    xxxx = np.arange(0.0001, 10.001, 0.001)  # 能量系数范围

    # 计算概率密度函数 (PDF)
    PDF_x_DBE = (1/xxxx) * (1/(np.sqrt(2*np.pi)*log_std_DBE)) * \
            np.exp(-((np.log(xxxx) - log_mean_DBE)**2 / (2*log_std_DBE**2)))

    # 计算累积分布函数 (CDF)
    CDF_x_DBE = cumulative_trapezoid(PDF_x_DBE, xxxx, initial=0)
    # 插值找到指定概率对应的能量系数
    gama_DBE_pre = np.interp(p, CDF_x_DBE, xxxx)

    return(gama_DBE_pre,gama_MCE_pre)