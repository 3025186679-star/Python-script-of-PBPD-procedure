import math
import Predict_gamma
import numpy as np
theta1_ = 0.3/100##预设目标位移角  rad
theta2_ = 1.5/100
theta3_ = 1.8/100
theta4_ = 2.25/100
a1_  = 0.05###预设滞回参数
a2_ = 0.6
a3_ = 0.1
ξ_  = 0.05
ξ1_ = theta2_/theta1_
ξ2_ = theta3_/theta1_
miu = theta4_/theta1_
T=0.0724*(26.4)**0.8*1.4##   m  公式经验周期
T=1.2##输入自定义周期
p=0.5##输入概率性能水平
Ss = 1.0##输入地震动加速度参数 ASCE 7-22
S1 = 0.85
Fv = 1.3
Fa = 2.4
gama_list = Predict_gamma.predict(a1_,a2_,a3_,ξ_,ξ1_,ξ2_,miu,T,p)###导入SGBoost模型和能量系数公式，计算DBE和MCE下的能量系数
gama_DBE_2  = gama_list[0]#DBE能量系数
gama_MCE_4  = float(gama_list[1].item())#MCE能量系数
print('γDBE2=',gama_DBE_2,'γMCE4=',gama_MCE_4)
g = 9800 #重力加速度 N/kg  mm/s^2  N/t
M=3778571.428571428*10**(-3) ##质量t

Sms = Ss*Fa
Sm1 = S1*Fv
T0 = 0.2*(Sm1/Sms)
Ts = (Sm1/Sms)
print('T=',T)
if T<=T0:
    Sa_MCE = Sms*(0.4+0.6*(T/T0))
    Sa_DBE = (2/3)*Sa_MCE
if T0<T<=Ts:
    Sa_MCE = Sms
    Sa_DBE = (2/3)*Sa_MCE
if Ts<T<=4.0:
    Sa_MCE = Sm1/T
    Sa_DBE = (2/3)*Sa_MCE
if T>4:
    Sa_MCE = Sm1*4/(T**2)
# print('Sa_DBE=',Sa_DBE,'Sa_MCE=',Sa_MCE)
###每层地震重量 到基底高度  分配系数
W1 = 6348.0*10**3 #kN
W2 = 6348.0*10**3 #kN
W3 = 6348.0*10**3 #kN
W4 = 6348.0*10**3 #kN
W5 = 6348.0*10**3 #kN
W6 = 5290.0*10**3 #kN
H1 = 5400  #mm
H2 = 9600  #mm
H3 = 13800 #mm
H4 = 18000 #mm
H5 = 22200 #mm
H6 = 26400 #mm
beta1 = ((W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6)/(W6*H6))**(0.75*T**(-0.2))
beta2 = ((W2*H2+W3*H3+W4*H4+W5*H5+W6*H6)/(W6*H6))**(0.75*T**(-0.2))
beta3 = ((W3*H3+W4*H4+W5*H5+W6*H6)/(W6*H6))**(0.75*T**(-0.2))
beta4 = ((W4*H4+W5*H5+W6*H6)/(W6*H6))**(0.75*T**(-0.2))
beta5 = ((W5*H5+W6*H6)/(W6*H6))**(0.75*T**(-0.2))
beta6 = ((W6*H6)/(W6*H6))**(0.75*T**(-0.2))
Cv1 = (beta1-beta2)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))##第一层分配系数
Cv2 = (beta2-beta3)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))##第二层分配系数
Cv3 = (beta3-beta4)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))##第三层分配系数
Cv4 = (beta4-beta5)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))##第四层分配系数
Cv5 = (beta5-beta6)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))##第五层分配系数
Cv6 = (beta6-0)*(((W6*H6)/(W1*H1+W2*H2+W3*H3+W4*H4+W5*H5+W6*H6))**(0.75*T**(-0.2)))    ##第六层分配系数
##计算DBE和MCE对应的基底剪力，取最大值
b_DBE_2 = (8*math.pi**2*((theta2_-theta1_)+a1_*(theta2_-theta1_)**2/(2*theta1_))*(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6))/(T**2)
Vy1_DBE_2=M*(((-b_DBE_2+np.sqrt(b_DBE_2**2+4*gama_DBE_2*(Sa_DBE*g)**2)))/2)
b_MCE_4 = (8*math.pi**2*((theta4_-theta1_)+((a1_*(theta2_-theta1_)*(2*theta4_-theta1_-theta2_)+a2_*(theta3_-theta2_)*(2*theta4_-theta3_-theta2_)+a3_*(theta4_-theta3_)**2))/(2*theta1_))*(Cv1*H1+Cv2*H2+Cv3*H3+Cv4*H4+Cv5*H5+Cv6*H6))/(T**2)
Vy1_MCE_4=M*(((-b_MCE_4+np.sqrt(b_MCE_4**2+4*gama_MCE_4*(Sa_MCE*g)**2)))/2)

V1_max = max(Vy1_DBE_2,Vy1_MCE_4)
print('V1_max=',V1_max )